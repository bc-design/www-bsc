# Content / Images

If using the standard file storage, Ghost will upload images to this directory.